/* ----------------------------------------------------------------------------
 *         ATMEL Microcontroller Software Support
 * ----------------------------------------------------------------------------
 * Copyright (c) 2006, Atmel Corporation

 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * - Redistributions of source code must retain the above copyright notice,
 * this list of conditions and the disclaimer below.
 *
 * Atmel's name may not be used to endorse or promote products derived from
 * this software without specific prior written permission.
 *
 * DISCLAIMER: THIS SOFTWARE IS PROVIDED BY ATMEL "AS IS" AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT ARE
 * DISCLAIMED. IN NO EVENT SHALL ATMEL BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA,
 * OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
#include "common.h"
#include "hardware.h"
#include "board.h"
#include "debug.h"
#include "slowclk.h"
#include "dataflash.h"
#include "nandflash.h"
#include "sdcard.h"
#include "flash.h"
#include "arch/at91_pio.h"
#include "gpio.h"

extern int load_kernel(struct image_info *img_info);

typedef int (*load_function)(struct image_info *img_info);

static load_function load_image;

static int init_loadfunction(void)
{
#if defined(CONFIG_LOAD_LINUX)
	load_image = &load_kernel;
#else
/*
#error "No booting media specified!"
#endif
*/
#endif
	return 0;
}

static void display_banner (void)
{
	dbg_log(1, "\n\r");
	dbg_log(1, "AT91Bootstrap %s\n\n\r",
			AT91BOOTSTRAP_VERSION" ( "COMPILE_TIME" )");
}

int main(void)
{
	struct image_info image_info;
	int ret;

	image_info.dest = (unsigned char *)JUMP_ADDR;
/**
 * @author Søren Andersen <san@rosetechnology.dk>
 */
        
#if defined (CONFIG_DATAFLASH) || defined(CONFIG_NANDFLASH) || defined(CONFIG_FLASH) 
	image_info.offset = IMG_ADDRESS;
	image_info.length = IMG_SIZE;
#endif
#if defined(CONFIG_SDCARD)
	image_info.filename = OS_IMAGE_NAME;
#endif

#ifdef CONFIG_HW_INIT
	hw_init();
#endif

	display_banner();

	init_loadfunction();

	dbg_log(1, "Downloading image...\n\r");
#if defined(CONFIG_FLASH)
        load_image = &load_norflash;
        ret = (*load_image)(&image_info);
        if (ret == 0){
                dbg_log(1, "Jump to NOR flash!\n\r");
                return JUMP_ADDR;
        }
        if (ret == -1) {
                dbg_log(1, "Failed to load NOR flash image\n\r");
        }
#endif

#if defined(CONFIG_SDCARD)	
		/* Only boot SD if "card detect" is low */
        if (pio_get_value(CONFIG_SYS_SD_CD_PIN) == 0) {
            load_image = &load_sdcard;
    	    ret = (*load_image)(&image_info);
    	    if (ret == 0){
	                dbg_log(1, "Jump to SD-Card!\n\r");
    	            return JUMP_ADDR;
    	    }
    	    if (ret == -1) {
    	            dbg_log(1, "Failed to load SD-Card image\n\r");
    	    }
	}
#endif


#if defined(CONFIG_DATAFLASH)
        load_image = &load_dataflash;
        ret = (*load_image)(&image_info);
        if (ret == 0){
		dbg_log(1, "Jump to Dataflash!\n\r");
                return JUMP_ADDR;
	}
        if (ret == -1) {
                dbg_log(1, "Failed to load Dataflash image\n\r");
        }
#endif

#ifdef CONFIG_SCLK
	slowclk_switch_osc32();
#endif

	return JUMP_ADDR;
}
